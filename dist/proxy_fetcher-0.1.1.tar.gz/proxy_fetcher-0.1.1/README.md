# Proxy Fetcher

Python package for fetching working HTTP proxies from multiple sources.

## Installation
```bash
pip install proxy-fetcher
```
