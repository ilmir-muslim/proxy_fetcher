from .core import ProxyFetcher, get_proxies

__all__ = ['ProxyFetcher', 'get_proxies']
__version__ = '0.1.1'